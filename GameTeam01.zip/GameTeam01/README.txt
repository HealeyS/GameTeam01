  _____          _   _  _____ ______    _____          __  __ ______               
 |  __ \   /\   | \ | |/ ____|  ____|  / ____|   /\   |  \/  |  ____|    TEAM01    
 | |  | | /  \  |  \| | |    | |__    | |  __   /  \  | \  / | |__                 
 | |  | |/ /\ \ | . ` | |    |  __|   | | |_ | / /\ \ | |\/| |  __|      HOW TO    
 | |__| / ____ \| |\  | |____| |____  | |__| |/ ____ \| |  | | |____               
 |_____/_/    \_\_| \_|\_____|______|  \_____/_/    \_\_|  |_|______|              
                 | |  | |  (_)         | |                                         
   __ _ _ __   __| |  | | ___ _ __   __| | __ _     __ _ _ __     _ __ _ __   __ _ 
  / _` | '_ \ / _` |  | |/ / | '_ \ / _` |/ _` |   / _` | '_ \   | '__| '_ \ / _` |
 | (_| | | | | (_| |  |   <| | | | | (_| | (_| |  | (_| | | | |  | |  | |_) | (_| |
  \__,_|_| |_|\__,_|  |_|\_\_|_| |_|\__,_|\__,_|   \__,_|_| |_|  |_|  | .__/ \__, |
                                                                      | |     __/ |
                                                                      |_|    |___/ 

 If you are using a joypad, please run joyBound.ahk through AutoHotkey
	DOWNLOAD: https://autohotkey.com/
 Sound is run through VLC, please ensure it is installed
	DOWNLOAD: http://www.videolan.org/vlc/download-windows.en_GB.html
 This only currently runs in Windows and has only been testing in Windows 10
 This is a Python3 script

 Use ARROW keys and ENTER. Use JOYPAD and CIRCLE alternatively

 Hit game.py to run the game! Have fun <3